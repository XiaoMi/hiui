# `@hiui-design/typical-page-shells`

This directory is the publishable runtime boundary for reusable HiUI typical page shells.

## Scope

The package exports only runtime page shells and host adapters:

- `pro-edit-page`
- `pro-detail-page`
- `pro-list-page`
- `pro-form-drawer`
- `pro-detail-drawer`
- `pro-table-page`
- `pro-stat-page`
- `pro-tree-split-page`
- `typical-page-host`

## Current state

The package now contains its own runtime source tree under `packages/typical-page-shells/src`.

The current repository still keeps the historical copies under `/src/components`, but the stable shell public entries can already be routed through this package boundary incrementally.

That keeps the migration safe:

1. current project can migrate shell-by-shell instead of a big-bang move
2. other repositories already have a concrete package source tree to consume
3. the remaining work is to finish switching the host project from old local copies to package-first imports

Those `/src/components/pro-*` paths should now be treated as compatibility facades for the current repository only. New runtime logic should not be added there; add it under `packages/typical-page-shells/src` and expose it through public package entrypoints instead.

## Host integration contract

Consumers must provide their own layout integration through `TypicalPageHostProvider`.

Consumers must also import the package styles once in the app entry:

```ts
import '@hiui-design/typical-page-shells/styles.css'
```

Minimal contract:

- provide `headerPortal` to mount page headers into the host layout header area
- optionally provide `footerPortal` if the host project uses footer slots
- keep layout-specific CSS and route wiring inside the host project

Example:

```tsx
import { TypicalPageHostProvider } from '@hiui-design/typical-page-shells/host'
import { PageHeaderPortal, PageFooterPortal } from '@/components/layout/portal'

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <TypicalPageHostProvider headerPortal={PageHeaderPortal} footerPortal={PageFooterPortal}>
      {children}
    </TypicalPageHostProvider>
  )
}
```

## Build

From the repository root:

```bash
pnpm build:typical-page-shells
```

Artifacts are emitted to `packages/typical-page-shells/dist`.

The package keeps deep subpath compatibility for current migration needs, including:

- `@hiui-design/typical-page-shells/pro-edit-page/types`
- `@hiui-design/typical-page-shells/pro-detail-page/types`
- `@hiui-design/typical-page-shells/pro-list-page/hooks/use-fetch-list`

## External example

See the host-side integration sample under:

- `[examples/host-integration/README.md](/Users/mi/Documents/git/hiui-design/examples/host-integration/README.md)`
- `[docs/external-project-host-integration.md](/Users/mi/Documents/git/hiui-design/docs/external-project-host-integration.md)`

For current-repository maintenance rules, compatibility-facade scope, and the source-of-truth relationship between `.local-context/.../examples/host-integration` and `src/typical-page-reuse`, see:

- `[docs/typical-page-maintenance-boundaries.md](/Users/mi/Documents/git/hiui-design/docs/typical-page-maintenance-boundaries.md)`
